# Todo

> * Add provision for adding more than one item in a single order
> * Add provision for more than one address
> * Cart thing to be managed later
> * Apply validation for ingredients while creating the item
> * fix password hashing issue for customers
> * PSQL or JSON field to be used ideally for storing ingredients list while creating an item.
